# simple-Mobile-Website-using-jQuery-Mobile.

Simple Mobile Website using jQuery Mobile.

Basic OMDB app.

http://127.0.0.1:5500/assignment-4A/index.html

